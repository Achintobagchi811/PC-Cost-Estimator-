import java.util.Scanner;

public class Inputsrc {


        Scanner sc = new Scanner(System.in);

}
