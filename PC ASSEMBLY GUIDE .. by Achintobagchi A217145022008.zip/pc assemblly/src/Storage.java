public class Storage extends Inputsrc {
    public int SataHDD() {
        System.out.println("===========================");
        System.out.println("choose NVME M.2 storage: ");
        System.out.println("---------------------------");
        System.out.println("1. HDD 50 GB (price=880)");
        System.out.println("2. HDD 150 GB (price=950)");
        System.out.println("3. HDD 250 GB (price=1000)");
        System.out.println("4. HDD 500 GB (price=1050)");
        System.out.println("5. HDD 750 GB (price=1100)");
        System.out.println("6. HDD 1 TB (price=2000)");
        System.out.println("7. HDD 2 TB (price=2800)");
        System.out.println("8. HDD 5 TB (price=3000)");

        int HDDchoice1 = sc.nextInt();
        switch (HDDchoice1) {
            case 1:
                return 880;//DDR5 4400 mzh
            case 2:
                return 950;// DDR5 5200 mzh
            case 3:
                return 1000;//DDR5 5600 mzh
            case 4:
                return 1050;//DDR5 6000 mzh
            case 5:
                return 1100;// DDR5 6200 mzh
            case 6:
                return 2000;//DDR5 6400 mzh
            case 7:
                return 2800;//DDR5 6600 mzh
            case 8:
                return 3000;//DDR5 6800 mzh
            default:
                System.out.println("Enter a valid number! ");
                SataHDD();
        }
        return 0;
    }


    public int SataSSD() {
        System.out.println("==============================");
        System.out.println("choose NVME M.2 SSD storage: ");
        System.out.println("-----------------------------");
        System.out.println("1. SATA SDD 50 GB (price=1200)");
        System.out.println("2. SATA SDD 150 GB (price=1500)");
        System.out.println("3. SATA SDD 250 GB (price=2000)");
        System.out.println("4. SATA SDD 500 GB (price=2500)");
        System.out.println("5. SATA SDD 750 GB (price=3000)");
        System.out.println("6. SATA SDD 1 TB (price=3500)");
        System.out.println("7. SATA SDD 2 TB (price=4800)");
        System.out.println("8. SATA SDD 5 TB (price=5000)");

        int HDDchoice2 = sc.nextInt();
        switch (HDDchoice2) {
            case 1:
                return 1200;//SATA SDD 50 GB
            case 2:
                return 1500;// DDR5 5200 mzh
            case 3:
                return 2000;//SATA SDD 150 GB
            case 4:
                return 2500;//SATA SDD 500 GB
            case 5:
                return 3000;// SATA SDD 750 GB
            case 6:
                return 3500;//SATA SDD 1 TB
            case 7:
                return 4800;//SATA SDD 2 TB
            case 8:
                return 5000;//SATA SDD 5 TB
            default:
                System.out.println("Enter a valid number! ");
                SataSSD();
        }
        return 0;
    }

    public int NVMESSD() {
        System.out.println("=================================");
        System.out.println("choose the NVME M.2 SSD storage: ");
        System.out.println("----------------------------------");
        System.out.println("1. NVME M.2 SDD 50 GB (price=3000)");
        System.out.println("2. NVME M.2 SDD 150 GB (price=4500)");
        System.out.println("3. NVME M.2 SDD 250 GB (price=5800)");
        System.out.println("4. NVME M.2 SDD 500 GB (price=6500)");
        System.out.println("5. NVME M.2 SDD 750 GB (price=7000)");
        System.out.println("6. NVME M.2 SDD 1 TB (price=7500)");
        System.out.println("7. NVME M.2 SDD 2 TB (price=8000)");
        System.out.println("8. NVME M.2 SDD 5 TB (price=10000)");

        int HDDchoice3 = sc.nextInt();
        switch (HDDchoice3) {
            case 1:
                return 3000;//NVME M.2 SATA SDD 50 GB
            case 2:
                return 4500;// NVME M.2 DDR5 5200 mzh
            case 3:
                return 5800;//NVME M.2 SATA SDD 150 GB
            case 4:
                return 6500;//NVME M.2 SATA SDD 500 GB
            case 5:
                return 7000;// NVME M.2 SATA SDD 750 GB
            case 6:
                return 7500;//NVME M.2 SATA SDD 1 TB
            case 7:
                return 8000;//NVME M.2 SATA SDD 2 TB
            case 8:
                return 10000;//NVME M.2 SATA SDD 5 TB
            default:
                System.out.println("Enter a valid number! ");
                NVMESSD();
        }
        return 0;
    }
}