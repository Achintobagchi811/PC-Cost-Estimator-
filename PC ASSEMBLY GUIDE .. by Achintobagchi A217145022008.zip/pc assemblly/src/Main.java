import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        boolean a1 = true;
        double priceList[]=new double[6] ;
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to PC Assemble program");
        System.out.println("Lets Assemble a new PC");


        //cpu
        while ( a1 ) {
            int newinp = -1;
            System.out.println("-------------------------------------");
            outer:
            System.out.println("Please choose the processor brand");
            System.out.println("1. Amd ");
            System.out.println("2. Intel ");
            CPU cp = new CPU();

            //exception handling
            try {
                newinp = sc.nextInt();
            }
            catch(InputMismatchException e){
                System.out.println("Please only Numarical value please re-run this program ");
                System.exit(0);
            }

            if (newinp == 1) {
                System.out.println("You have selected 'AMD'");
                priceList[0] = cp.AMD();
                a1 = false;
            } else if (newinp == 2) {
                System.out.println("You have selected 'Intel'");
                priceList[0] = cp.Intel();
                a1 = false;
            } else {
                System.out.println("You have selected a wrong number please re-enter a valid number! ");
                //a1 = true;
            }
            System.out.println("your total cost until now= " + priceList[0]);
        }

        //RAM
        boolean a2 = true;
        while ( a2 ) {
            int newinp2=-1;
            System.out.println("-------------------------------------");
            System.out.println("Please choose the RAM type- ");
            System.out.println("1. DDR4 ");
            System.out.println("2. DDR5 ");
            RAM rm = new RAM();


            //exception handling
            try {
                newinp2 = sc.nextInt();
            }
            catch(InputMismatchException e){
                System.out.println("Please only Numarical value please re-run this program");
                System.exit(0);

            }


            if (newinp2 == 1) {
                System.out.println("You have selected 'DDR4'");
                priceList[1] = rm.DDR4();
                a2 = false;
            } else if (newinp2 == 2) {
                System.out.println("You have selected 'DDR5'");
                priceList[1] = rm.DDR5();
                a2 = false;
            } else {
                System.out.println("You have selected a wrong number please re-enter a valid number! ");
                //a2 = true;
            }
            System.out.println("your total cost until now= " + (priceList[0] + priceList[1]));
        }

        //GPU
        boolean a3 = true;
        while ( a3 ) {
            int newinp3=-1;
            System.out.println("-------------------------------------");
            System.out.println("Please choose the GPU type- ");
            System.out.println("1. 10 series ");
            System.out.println("2. 20 series ");
            System.out.println("3. 30 series ");
            GPU gp = new GPU();

            //exception handling
            try {
                newinp3 = sc.nextInt();
            }
            catch(InputMismatchException e){
                System.out.println("Please only Numarical value please re-run this program ");
                System.exit(0);

            }


            if (newinp3 == 1) {
                System.out.println("You have selected '10 series'");
                priceList[2] = gp.Gtx10000();
                a3 = false;
            } else if (newinp3 == 2) {
                System.out.println("You have selected '20 series'");
                priceList[2] = gp.Gtx20000();
                a3 = false;
            } else if (newinp3 == 3) {
                System.out.println("You have selected '30 series'");
                priceList[2] = gp.Gtx30000();
                a3 = false;
            } else {
                System.out.println("You have selected a wrong number please re-enter a valid number! ");
               //a3 = true;
            }
            System.out.println("your total cost until now= " + (priceList[0] + priceList[1] + priceList[2]));
        }


        //motherbord
        boolean a4 = true;
        while ( a4 ) {
            int newinp4=-1;
            System.out.println("-------------------------------------");
            System.out.println("Please choose the Motherbord type- ");
            System.out.println("1. if you have chosen AMD ");
            System.out.println("2. if you have chosen INTEL ");
            Motherbord mb = new Motherbord();

            //exception handling
            try {
                 newinp4 = sc.nextInt();
            }
            catch(InputMismatchException e){
                System.out.println("Please only Numarical value please re-run this program ");
                System.exit(0);

            }

            if (newinp4 == 1) {
                System.out.println("You have selected 'AMD Motherbords'");
                priceList[3] = mb.AMDmb();
                a4 = false;
            } else if (newinp4 == 2) {
                System.out.println("You have selected 'Intel Motherbords'");
                priceList[3] = mb.Intelmb();
                a4 = false;
            } else {
                System.out.println("You have selected a wrong number please re-enter a valid number! ");
                //a4 = true;
            }
            System.out.println("your total cost until now= " + (priceList[0] + priceList[1] + priceList[2] + priceList[3]));
        }


        boolean a5 = true;
        while(a5) {
            int newinp5=-1;
            System.out.println("-------------------------------------");
            System.out.println("Please choose the Storage device type- ");
            System.out.println("1. SATA Hard-Disk ");
            System.out.println("2. SATA Solid-State-Drive ");
            System.out.println("3. NVME M.2 Solid-State-Drive ");
            Storage st = new Storage();

            //exception handling
            try {
                newinp5 = sc.nextInt();
            }
            catch(InputMismatchException e){
                System.out.println("Please only Numarical value please re-run this program   ");
                System.exit(0);

            }


            if (newinp5 == 1) {
                System.out.println("You have selected 'SATA HDD'");
                priceList[4] = st.SataHDD();
                a5 = false;
            } else if (newinp5 == 2) {
                System.out.println("You have selected 'SATA SSD'");
                priceList[4] = st.SataSSD();
                a5 = false;
            } else if (newinp5 == 3) {
                System.out.println("You have selected 'NVME M.2 SSD'");
                priceList[4] = st.NVMESSD();
                a5 = false;
            } else {
                System.out.println("You have selected a wrong number please re-enter a valid number!");
                //a5 = true;
            }
            System.out.println("your total cost until now= " + (priceList[0] + priceList[1] + priceList[2] + priceList[3] + priceList[4]));
        }
        System.out.println( "total cost of your PC is:" + (priceList[0]+priceList[1]+priceList[2]+priceList[3]+priceList[4]));
    }
    }



