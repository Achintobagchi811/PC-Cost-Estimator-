public class GPU extends Inputsrc {
    public int Gtx10000() {
        System.out.println("====================================");
        System.out.println("choose the Series of grafic card: ");
        System.out.println("------------------------------------");
        System.out.println("1. 1030  (price=8000)");
        System.out.println("2. 1050   (price=9000) ");
        System.out.println("3. 1050ti (price=12000)");
        System.out.println("4. 1060 (price=13000)");
        System.out.println("5. 1060ti  (price=14000)");
        System.out.println("6. 1070 (price=15000)");
        System.out.println("7. 1070ti (price=16000)");
        System.out.println("8. 1080 (price=17000)");
        System.out.println("8. 1080ti (price=18000)");
        int gpuchoice1 = sc.nextInt();

        switch (gpuchoice1) {
            case 1:
                return 8000;//1030
            case 2:
                return 9000;//1050
            case 3:
                return 12000;//050ti
            case 4:
                return 13000;//1060
            case 5:
                return 14000;//1060ti
            case 6:
                return 15000;//1070
            case 7:
                return 16000;//1070ti
            case 8:
                return 17000;//1080
            case 9:
                return 18000;//1080ti
            default:
                System.out.println("Enter a valid number! ");
                Gtx10000();
        }
        return 0;
    }

    public int Gtx20000() {
        System.out.println("====================================");
        System.out.println("choose the Series of grafic card: ");
        System.out.println("------------------------------------");
        System.out.println("1. 2030  (price=11000)");
        System.out.println("2. 2050   (price=15000) ");
        System.out.println("3. 2050ti (price=18000)");
        System.out.println("4. 2060 (price=22000)");
        System.out.println("5. 2060ti  (price=25000)");
        System.out.println("6. 2070 (price=32000)");
        System.out.println("7. 2070ti (price=35000)");
        System.out.println("8. 2080 (price=45000)");
        System.out.println("9. 2080ti (price=50000)");
        int gpuchoice2 = sc.nextInt();

        switch (gpuchoice2) {
            case 1:
                return 11000;//2030
            case 2:
                return 15000;//2050
            case 3:
                return 18000;//250ti
            case 4:
                return 22000;//2060
            case 5:
                return 25000;//2060ti
            case 6:
                return 32000;//2070
            case 7:
                return 35000;//2070ti
            case 8:
                return 45000;//2080
            case 9:
                return 50000;//2080ti
            default:
                System.out.println("Enter a valid number! ");
                Gtx20000();
        }
        return 0;
    }

    public int Gtx30000() {
        System.out.println("====================================");
        System.out.println("choose the Series of grafic card: ");
        System.out.println("------------------------------------");
        System.out.println("1. 3030  (price=11000)");
        System.out.println("2. 3050   (price=25000) ");
        System.out.println("3. 3050ti (price=28000)");
        System.out.println("4. 3060 (price=32000)");
        System.out.println("5. 3060ti  (price=35000)");
        System.out.println("6. 3070 (price=42000)");
        System.out.println("7. 3070ti (price=55000)");
        System.out.println("8. 3080 (price=65000)");
        System.out.println("9. 3080ti (price=80000)");
        int gpuchoice2 = sc.nextInt();

        switch (gpuchoice2) {
            case 1:
                return 11000;//2030
            case 2:
                return 25000;//2050
            case 3:
                return 28000;//250ti
            case 4:
                return 32000;//2060
            case 5:
                return 35000;//2060ti
            case 6:
                return 42000;//2070
            case 7:
                return 55000;//2070ti
            case 8:
                return 65000;//2080
            case 9:
                return 80000;//2080ti
            default:
                System.out.println("Enter a valid number! ");
                Gtx30000();
        }
        return 0;
    }
}