public class Motherbord extends Inputsrc {
    public int Intelmb() {
        System.out.println("=================================");
        System.out.println("choose the Motherbord chipset: ");
        System.out.println("--------------------------------");
        System.out.println("1. B560 (price=12000)");
        System.out.println("2. B690  (price=8500) ");
        System.out.println("3. H610 (price=21000)");
        System.out.println("4. B660  (price=23000)");
        System.out.println("5. Z590 (price=31000)");
        System.out.println("6. Z690 (price=25000)");


        int mbchoice1 = sc.nextInt();
        switch (mbchoice1) {
            case 1:
                return 12000;//B560
            case 2:
                return 8500;//B690
            case 3:
                return 21000;//H610
            case 4:
                return 23000;//B660
            case 5:
                return 31000;//Z590
            case 6:
                return 25000;//Z690

            default:
                System.out.println("Enter a valid number! ");
                Intelmb();
        }
        return 0;

    }


    public double AMDmb() {
        double price=0.0;
        System.out.println("================================");
        System.out.println("choose the Motherbord chipset: ");
        System.out.println("-------------------------------");
        System.out.println("1. A320 (price=8000)");
        System.out.println("2. B350  (price=11000) ");
        System.out.println("3. B450 (price=13000)");
        System.out.println("4. B550  (price=23000)");
        System.out.println("5. X570 (price=31000)");
        System.out.println("6. Z570M (price=35000)");


        int mbchoice2 = sc.nextInt();
        switch (mbchoice2) {
            case 1:
                price= 8000;//A320
                break;
            case 2:
                price= 11000;//B350
                break;
            case 3:
                price= 13000;//B450
                break;
            case 4:
                price= 23000;//B550
                break;
            case 5:
                price= 31000;//X570
                break;
            case 6:
                price= 35000;//Z570M
                break;

            default:
                System.out.println("Enter a valid number! ");
                AMDmb();
        }
        return price;

    }
}