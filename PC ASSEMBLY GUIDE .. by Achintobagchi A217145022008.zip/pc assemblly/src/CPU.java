public class CPU extends Inputsrc
{
    //Motherbord mb = new Motherbord();
    public int AMD() {
        System.out.println("===============================");
        System.out.println("choose the RYZEN type and gen: ");
        System.out.println("-------------------------------");
        System.out.println("1. RYZEN 3 gen 5 (price=12000)");
        System.out.println("2. RYZEN 3 gen 6 (price=16000)");
        System.out.println("3. RYZEN 5 gen 5 (price=21000)");
        System.out.println("4. RYZEN 5 gen 6 (price=25000)");
        System.out.println("5. RYZEN 7 gen 5 (price=32000)");
        System.out.println("6. RYZEN 7 gen 6 (price= 36000)");
        System.out.println("7. RYZEN 9 gen 5 (price=42000)");
        System.out.println("8. RYZEN 9 gen 6 (price=48000)");

        int choice1 = sc.nextInt();
        switch (choice1) {
            case 1:
                return 12000;//3 gen 5:
            case 2:
                return 16000;//3 gen 6
            case 3:
                return 21000;//5 gen 5
            case 4:
                return 25000;//5 gen 6
            case 5:
                return 32000;//7 gen 5
            case 6:
                return 36000;//7 gen 6
            case 7:
                return 42000;//9 gen 5
            case 8:
                return 48000;//9 gen 6
            default:
                System.out.println("Enter a valid number! ");
                AMD();

        }
        return 0;

    }

    public int Intel() {
        System.out.println("===============================");
        System.out.println("choose the INTEL type and gen: ");
        System.out.println("-------------------------------");
        System.out.println("1. intel i3 gen 11 (price=12000)");
        System.out.println("2. intel i3 gen 12 (price=16000)");
        System.out.println("3. intel i5 gen 11 (price=21000)");
        System.out.println("4. intel i5 gen 12 (price=25000)");
        System.out.println("5. intel i7 gen 11 (price=32000)");
        System.out.println("6. intel i7 gen 12 (price=36000)");
        System.out.println("7. intel i9 gen 11 (price=42000)");
        System.out.println("8. intel i9 gen 12 (price=48000)");

        int choice2 = sc.nextInt();
        switch (choice2) {
            case 1:
                return 12000;//i3 gen 11:
            case 2:
                return 16000;//i3 gen 12
            case 3:
                return 21000;//i5 gen 11
            case 4:
                return 25000;//i5 gen 12
            case 5:
                return 32000;//i7 gen 11
            case 6:
                return 36000;//i7 gen 12
            case 7:
                return 42000;//i9 gen 11
            case 8:
                return 48000;//i9 gen 12
            default:
                System.out.println("Enter a valid number! ");

                Intel();
        }
        return 0;

    }
}
