import java.util.Scanner;

public class RAM extends Inputsrc
{
    public int DDR4() {
        System.out.println("===============================");
        System.out.println("choose the DDR4 speed: ");
        System.out.println("-------------------------------");
        System.out.println("1. DDR4 1600 mzh (price=1000)");
        System.out.println("2. DDR4 1866 mzh (price=1600)");
        System.out.println("3. DDR4 2133 mzh (price=2200)");
        System.out.println("4. DDR4 2400 mzh (price=2800)");
        System.out.println("5. DDR4 2666 mzh (price=3400)");
        System.out.println("6. DDR4 2933 mzh (price=3800)");
        System.out.println("7. DDR4 3200 mzh (price=4400)");
        System.out.println("8. DDR4 2933 mzh (price=4900)");

        int Ramchoice1 = sc.nextInt();
        switch (Ramchoice1) {
            case 1:
                return 1000;//DDR4 1600 mzh:
            case 2:
                return 1600;// DDR4 1866 mzh
            case 3:
                return 2200;//DDR4 2133 mzh
            case 4:
                return 2800;//DDR4 2400 mzh
            case 5:
                return 3400;//DDR4 2666 mzh
            case 6:
                return 3800;//DDR4 2933 mzh
            case 7:
                return 4400;//DDR4 3200 mzh
            case 8:
                return 4900;//DDR4 2933 mzh
            default:
                System.out.println("Enter a valid number! ");
                DDR4();
        }
        return 0;
    }

    public int DDR5() {
        System.out.println("============================");
        System.out.println("choose the DDR5 speed: ");
        System.out.println("---------------------------");
        System.out.println("1. DDR5 4400 mzh (price=8000) ");
        System.out.println("2. DDR5 5200 mzh (price=9500)");
        System.out.println("3. DDR5 5600 mzh (price=10000)");
        System.out.println("4. DDR5 6000 mzh (price=10500)");
        System.out.println("5. DDR5 6200 mzh (price=11000)");
        System.out.println("6. DDR5 6400 mzh (price=11500)");
        System.out.println("7. DDR5 6600 mzh (price=12000)");
        System.out.println("8. DDR5 6800 mzh (price=13000)");

        int Ramchoice2 = sc.nextInt();
        switch (Ramchoice2) {
            case 1:
                return 8800;//DDR5 4400 mzh
            case 2:
                return 9500;// DDR5 5200 mzh
            case 3:
                return 10000;//DDR5 5600 mzh
            case 4:
                return 10500;//DDR5 6000 mzh
            case 5:
                return 11000;// DDR5 6200 mzh
            case 6:
                return 11500;//DDR5 6400 mzh
            case 7:
                return 12000;//DDR5 6600 mzh
            case 8:
                return 13000;//DDR5 6800 mzh
            default:
                System.out.println("Enter a valid number! ");
                DDR5();
        }
        return 0;
    }
}
